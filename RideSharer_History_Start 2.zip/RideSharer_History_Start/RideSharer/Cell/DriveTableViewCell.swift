//
//  DriveTableViewCell.swift
//  RideSharer
//
//  Created by Roshan Shinde on 19/07/23.
//

import UIKit

class DriveTableViewCell: UITableViewCell {
    @IBOutlet weak var driverLbl: UILabel!
    @IBOutlet weak var mapButton: UIButton!
    @IBOutlet weak var priceLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        mapButton.setTitle("", for: .normal)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
